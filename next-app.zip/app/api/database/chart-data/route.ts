import { NextResponse } from 'next/server';
import { getPool } from '@/lib/db';

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { table, xAxis, yAxis, aggregation = 'sum', groupBy, orderBy, orderDirection = 'ASC', limit = 50 } = body;

        if (!table || !xAxis || !yAxis || yAxis.length === 0) {
            return NextResponse.json({
                success: false,
                error: 'Missing required fields: table, xAxis, yAxis',
            }, { status: 400 });
        }

        const pool = await getPool();

        // First verify table exists
        const tableCheck = await pool.request()
            .input('tableName', table)
            .query(`
                SELECT TABLE_SCHEMA, TABLE_NAME 
                FROM INFORMATION_SCHEMA.TABLES 
                WHERE TABLE_NAME = @tableName
            `);

        if (tableCheck.recordset.length === 0) {
            return NextResponse.json({
                success: false,
                error: `Table '${table}' not found`,
            }, { status: 404 });
        }

        const schema = tableCheck.recordset[0].TABLE_SCHEMA;
        const tableName = tableCheck.recordset[0].TABLE_NAME;

        // Build aggregation function
        const aggFunc = aggregation.toUpperCase();
        const validAggFunctions = ['SUM', 'AVG', 'COUNT', 'MIN', 'MAX'];
        const selectedAgg = validAggFunctions.includes(aggFunc) ? aggFunc : 'SUM';

        // Build SELECT clause for Y axis columns with aggregation
        const yAxisSelects = yAxis.map((col: string) => {
            // Escape column name
            const escapedCol = col.replace(/[^\w]/g, '');
            return `${selectedAgg}([${escapedCol}]) as [${escapedCol}]`;
        }).join(', ');

        // Escape xAxis column name
        const escapedXAxis = xAxis.replace(/[^\w]/g, '');
        const groupByCol = groupBy || xAxis;
        const escapedGroupBy = groupByCol.replace(/[^\w]/g, '');

        // Build query with GROUP BY and ORDER BY
        const sortCol = orderBy || escapedXAxis;
        const sortDir = orderDirection.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

        const query = `
            SELECT TOP ${limit}
                [${escapedXAxis}] as [${escapedXAxis}],
                ${yAxisSelects}
            FROM [${schema}].[${tableName}]
            WHERE [${escapedXAxis}] IS NOT NULL
            GROUP BY [${escapedXAxis}]
            ORDER BY [${sortCol}] ${sortDir}
        `;

        console.log('Executing chart query:', query);

        const result = await pool.request().query(query);

        return NextResponse.json({
            success: true,
            data: result.recordset,
        });
    } catch (error) {
        console.error('Error fetching chart data:', error);
        return NextResponse.json({
            success: false,
            error: error instanceof Error ? error.message : 'Failed to fetch chart data',
        }, { status: 500 });
    }
}
