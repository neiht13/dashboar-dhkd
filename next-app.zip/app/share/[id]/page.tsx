"use client";

import React, { useEffect, useState, use } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, LayoutDashboard } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { DynamicChart } from "@/components/charts/DynamicChart";
import { cn } from "@/lib/utils";
import type { Dashboard, Widget, LayoutItem, ChartConfig } from "@/types";

interface SharePageProps {
    params: Promise<{ id: string }>;
}

const GRID_COLS = 12;
const CELL_HEIGHT = 60;
const GAP = 16;

export default function ShareDashboardPage({ params }: SharePageProps) {
    const { id } = use(params);
    const router = useRouter();
    const [dashboard, setDashboard] = useState<Dashboard | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [chartDataCache, setChartDataCache] = useState<Record<string, any[]>>({});

    // Load dashboard
    useEffect(() => {
        const loadDashboard = async () => {
            try {
                // Use public API endpoint (no auth required)
                const response = await fetch(`/api/public/dashboards/${id}`);
                const result = await response.json();

                if (result.success && result.data) {
                    setDashboard({
                        ...result.data,
                        id: result.data._id || result.data.id,
                    });
                } else {
                    // Fallback: try to load from localStorage
                    const stored = localStorage.getItem('dashboard-storage');
                    if (stored) {
                        const parsed = JSON.parse(stored);
                        const found = parsed.state?.dashboards?.find((d: any) => d.id === id);
                        if (found) {
                            setDashboard(found);
                        } else {
                            setError("Dashboard không tồn tại");
                        }
                    } else {
                        setError("Dashboard không tồn tại");
                    }
                }
            } catch (err) {
                // Fallback to localStorage
                try {
                    const stored = localStorage.getItem('dashboard-storage');
                    if (stored) {
                        const parsed = JSON.parse(stored);
                        const found = parsed.state?.dashboards?.find((d: any) => d.id === id);
                        if (found) {
                            setDashboard(found);
                        } else {
                            setError("Dashboard không tồn tại");
                        }
                    }
                } catch {
                    setError("Không thể tải dashboard");
                }
            } finally {
                setLoading(false);
            }
        };

        loadDashboard();
    }, [id]);

    // Fetch chart data
    useEffect(() => {
        if (!dashboard) return;

        const fetchChartData = async (widgetId: string, config: ChartConfig) => {
            if (!config.dataSource?.table || !config.dataSource?.xAxis || !config.dataSource?.yAxis?.length) {
                return;
            }

            try {
                const response = await fetch("/api/database/chart-data", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        table: config.dataSource.table,
                        xAxis: config.dataSource.xAxis,
                        yAxis: config.dataSource.yAxis,
                        aggregation: config.dataSource.aggregation || "sum",
                        limit: 50,
                    }),
                });

                const result = await response.json();
                if (result.success && result.data) {
                    setChartDataCache(prev => ({
                        ...prev,
                        [widgetId]: result.data,
                    }));
                }
            } catch (error) {
                console.error("Error fetching chart data:", error);
            }
        };

        dashboard.widgets.forEach(widget => {
            if (widget.type === "chart" && !chartDataCache[widget.id]) {
                const config = widget.config as ChartConfig;
                fetchChartData(widget.id, config);
            }
        });
    }, [dashboard]);

    const renderWidgetContent = (widget: Widget) => {
        const height = ((widget.layout?.h || 3) * CELL_HEIGHT) - 40;

        switch (widget.type) {
            case "chart":
                const chartConfig = widget.config as ChartConfig;
                const chartData = chartDataCache[widget.id] || [];

                return (
                    <div className="w-full h-full flex flex-col">
                        {chartConfig.name && (
                            <div className="px-3 pt-2 pb-1">
                                <h4 className="text-sm font-medium text-[#0F172A] truncate">
                                    {chartConfig.name}
                                </h4>
                            </div>
                        )}
                        <div className="flex-1 min-h-0 p-2">
                            <DynamicChart
                                config={chartConfig}
                                data={chartData}
                                height={Math.max(120, height)}
                            />
                        </div>
                    </div>
                );
            case "kpi":
                return (
                    <div className="flex flex-col items-center justify-center h-full">
                        <span className="text-sm text-[#64748B]">{(widget.config as any).title}</span>
                        <span className="text-3xl font-bold text-[#0F172A]">1,234</span>
                    </div>
                );
            case "text":
                return (
                    <div className="p-4 overflow-auto h-full">
                        <div
                            className={cn("prose max-w-none", {
                                "text-center": (widget.config as any).textAlign === "center",
                                "text-right": (widget.config as any).textAlign === "right",
                            })}
                            style={{ fontSize: (widget.config as any).fontSize || 16 }}
                        >
                            {(widget.config as any).content}
                        </div>
                    </div>
                );
            default:
                return null;
        }
    };

    const getWidgetStyle = (layout: LayoutItem | undefined, containerWidth: number) => {
        const x = layout?.x || 0;
        const y = layout?.y || 0;
        const w = layout?.w || 4;
        const h = layout?.h || 3;

        const cellWidth = (containerWidth - (GRID_COLS - 1) * GAP) / GRID_COLS;

        return {
            position: "absolute" as const,
            left: x * (cellWidth + GAP),
            top: y * (CELL_HEIGHT + GAP),
            width: w * cellWidth + (w - 1) * GAP,
            height: h * CELL_HEIGHT + (h - 1) * GAP,
        };
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC]">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0052CC] mx-auto mb-4"></div>
                    <p className="text-[#64748B]">Đang tải dashboard...</p>
                </div>
            </div>
        );
    }

    if (error || !dashboard) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC]">
                <div className="text-center">
                    <LayoutDashboard className="h-16 w-16 text-[#CBD5E1] mx-auto mb-4" />
                    <h1 className="text-xl font-bold text-[#0F172A] mb-2">Dashboard không tìm thấy</h1>
                    <p className="text-[#64748B] mb-4">{error || "Link này có thể đã hết hạn hoặc không tồn tại."}</p>
                    <Button onClick={() => router.push("/dashboard")}>
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Về trang chủ
                    </Button>
                </div>
            </div>
        );
    }

    const containerWidth = 1200;
    let maxRow = 8;
    const validWidgets = (dashboard.widgets || []).filter(w => w && w.id);
    validWidgets.forEach(widget => {
        const y = widget.layout?.y ?? 0;
        const h = widget.layout?.h ?? 3;
        maxRow = Math.max(maxRow, y + h + 1);
    });
    const gridHeight = maxRow * CELL_HEIGHT + (maxRow - 1) * GAP;

    return (
        <div className="min-h-screen bg-[#F8FAFC]">
            {/* Header */}
            <div className="bg-white border-b border-[#E2E8F0] px-6 py-4">
                <div className="max-w-[1400px] mx-auto">
                    <h1 className="text-xl font-bold text-[#0F172A]">{dashboard.name}</h1>
                    {dashboard.description && (
                        <p className="text-sm text-[#64748B] mt-1">{dashboard.description}</p>
                    )}
                </div>
            </div>

            {/* Dashboard Content */}
            <div className="p-6">
                <div className="max-w-[1400px] mx-auto">
                    <div
                        className="relative"
                        style={{ height: gridHeight, width: containerWidth }}
                    >
                        {validWidgets.length === 0 ? (
                            <div className="flex items-center justify-center h-full">
                                <p className="text-[#94A3B8]">Dashboard này chưa có widget nào</p>
                            </div>
                        ) : (
                            validWidgets.map((widget) => (
                                <Card
                                    key={widget.id}
                                    className="overflow-hidden bg-white shadow-md border-[#E2E8F0]"
                                    style={getWidgetStyle(widget.layout, containerWidth)}
                                >
                                    <CardContent className="p-0 h-full">
                                        {renderWidgetContent(widget)}
                                    </CardContent>
                                </Card>
                            ))
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
