"use client";

import React, { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import {
    Save,
    ArrowLeft,
    BarChart3,
    LineChart,
    PieChart,
    Activity,
    Radar,
    Database,
    CircleDot,
    Layers,
    ArrowRightLeft,
    GitMerge,
    Filter,
    Palette,
    Settings2,
    Search,
    ChevronDown,
    Loader2,
} from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { DynamicChart } from "@/components/charts/DynamicChart";
import { useChartStore } from "@/stores/chart-store";
import type { ChartType, ChartConfig, AggregationType } from "@/types";
import { generateId, defaultChartColors } from "@/lib/utils";
import { cn } from "@/lib/utils";

interface TableInfo {
    schema: string;
    name: string;
    rowCount: number;
}

interface ColumnInfo {
    name: string;
    type: string;
    nullable: string;
    isPrimaryKey: number;
}

const chartTypes: { type: ChartType; label: string; icon: React.ReactNode }[] = [
    { type: "bar", label: "Cột", icon: <BarChart3 className="h-5 w-5" /> },
    { type: "stackedBar", label: "Cột chồng", icon: <Layers className="h-5 w-5" /> },
    { type: "horizontalBar", label: "Cột ngang", icon: <ArrowRightLeft className="h-5 w-5" /> },
    { type: "line", label: "Đường", icon: <LineChart className="h-5 w-5" /> },
    { type: "area", label: "Vùng", icon: <Activity className="h-5 w-5" /> },
    { type: "pie", label: "Tròn", icon: <PieChart className="h-5 w-5" /> },
    { type: "donut", label: "Donut", icon: <CircleDot className="h-5 w-5" /> },
    { type: "radar", label: "Radar", icon: <Radar className="h-5 w-5" /> },
    { type: "composed", label: "Kết hợp", icon: <GitMerge className="h-5 w-5" /> },
    { type: "funnel", label: "Phễu", icon: <Filter className="h-5 w-5" /> },
];

// Fallback demo data
const fallbackDemoData = [
    { name: "Mẫu 1", value: 100 },
    { name: "Mẫu 2", value: 200 },
    { name: "Mẫu 3", value: 150 },
];

export default function ChartDesignerPage() {
    const router = useRouter();
    const {
        currentChart,
        updateChartType,
        updateDataSource,
        saveChart,
        resetCurrentChart,
    } = useChartStore();

    const [chartName, setChartName] = useState("");

    // Database tables
    const [tables, setTables] = useState<TableInfo[]>([]);
    const [isLoadingTables, setIsLoadingTables] = useState(true);
    const [tableSearchQuery, setTableSearchQuery] = useState("");
    const [showTableDropdown, setShowTableDropdown] = useState(false);
    const [selectedTable, setSelectedTable] = useState("");
    const tableDropdownRef = useRef<HTMLDivElement>(null);

    // Columns
    const [columns, setColumns] = useState<ColumnInfo[]>([]);
    const [isLoadingColumns, setIsLoadingColumns] = useState(false);
    const [selectedXAxis, setSelectedXAxis] = useState("");
    const [selectedYAxis, setSelectedYAxis] = useState<string[]>([]);
    const [aggregation, setAggregation] = useState<AggregationType>("sum");
    const [orderBy, setOrderBy] = useState("");
    const [orderDirection, setOrderDirection] = useState<"asc" | "desc">("asc");

    // Chart data
    const [chartData, setChartData] = useState<Record<string, unknown>[]>([]);
    const [isLoadingChartData, setIsLoadingChartData] = useState(false);
    const [chartDataError, setChartDataError] = useState<string | null>(null);

    // Style options
    const [showLegend, setShowLegend] = useState(true);
    const [legendPosition, setLegendPosition] = useState<"top" | "bottom" | "left" | "right">("bottom");
    const [showGrid, setShowGrid] = useState(true);
    const [showDataLabels, setShowDataLabels] = useState(false);
    const [xAxisLabel, setXAxisLabel] = useState("");
    const [yAxisLabel, setYAxisLabel] = useState("");
    const [titleFontSize, setTitleFontSize] = useState(14);
    const [activeTab, setActiveTab] = useState<"data" | "style">("data");

    // Fetch tables on mount
    useEffect(() => {
        resetCurrentChart();
        fetchTables();
    }, [resetCurrentChart]);

    // Click outside to close dropdown
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (tableDropdownRef.current && !tableDropdownRef.current.contains(event.target as Node)) {
                setShowTableDropdown(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    // Fetch chart data when configuration changes
    useEffect(() => {
        if (selectedTable && selectedXAxis && selectedYAxis.length > 0) {
            fetchChartData();
        }
    }, [selectedTable, selectedXAxis, selectedYAxis, aggregation, orderBy, orderDirection]);

    const fetchTables = async () => {
        setIsLoadingTables(true);
        try {
            const response = await fetch("/api/database/tables");
            const result = await response.json();
            if (result.success && result.data?.tables) {
                setTables(result.data.tables);
            }
        } catch (error) {
            console.error("Error fetching tables:", error);
        } finally {
            setIsLoadingTables(false);
        }
    };

    const fetchColumns = async (tableName: string) => {
        setIsLoadingColumns(true);
        setColumns([]);
        setSelectedXAxis("");
        setSelectedYAxis([]);
        setOrderBy("");

        try {
            const response = await fetch(`/api/database/schema/${encodeURIComponent(tableName)}`);
            const result = await response.json();
            if (result.success && result.data?.columns) {
                setColumns(result.data.columns);
            }
        } catch (error) {
            console.error("Error fetching columns:", error);
        } finally {
            setIsLoadingColumns(false);
        }
    };

    const fetchChartData = async () => {
        if (!selectedTable || !selectedXAxis || selectedYAxis.length === 0) {
            return;
        }

        setIsLoadingChartData(true);
        setChartDataError(null);

        try {
            const response = await fetch('/api/database/chart-data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    table: selectedTable,
                    xAxis: selectedXAxis,
                    yAxis: selectedYAxis,
                    aggregation: aggregation,
                    orderBy,
                    orderDirection,
                    limit: 50,
                }),
            });

            const result = await response.json();
            if (result.success && result.data) {
                setChartData(result.data);
                console.log('Chart data loaded:', result.data.length, 'rows');
            } else {
                setChartDataError(result.error || 'Không thể tải dữ liệu biểu đồ');
                setChartData([]);
            }
        } catch (error) {
            console.error('Error fetching chart data:', error);
            setChartDataError('Lỗi kết nối khi tải dữ liệu');
            setChartData([]);
        } finally {
            setIsLoadingChartData(false);
        }
    };

    const handleTableSelect = (tableName: string) => {
        setSelectedTable(tableName);
        setTableSearchQuery(tableName);
        setShowTableDropdown(false);
        updateDataSource({ table: tableName });
        fetchColumns(tableName);
    };

    const handleXAxisChange = (xAxis: string) => {
        setSelectedXAxis(xAxis);
        // Default orderBy to xAxis
        if (!orderBy) setOrderBy(xAxis);
        updateDataSource({ xAxis });
    };

    const handleYAxisToggle = (field: string) => {
        const newYAxis = selectedYAxis.includes(field)
            ? selectedYAxis.filter((f) => f !== field)
            : [...selectedYAxis, field];
        setSelectedYAxis(newYAxis);
        updateDataSource({ yAxis: newYAxis });
    };

    const handleSaveChart = () => {
        const chartConfig: ChartConfig = {
            id: generateId(),
            name: chartName || "Biểu đồ chưa đặt tên",
            type: currentChart.type || "bar",
            dataSource: {
                table: selectedTable,
                xAxis: selectedXAxis,
                yAxis: selectedYAxis,
                aggregation,
                orderBy,
                orderDirection,
            },
            style: {
                colors: defaultChartColors,
                showLegend,
                legendPosition,
                showGrid,
                showTooltip: true,
                showDataLabels,
                xAxisLabel,
                yAxisLabel,
                title: chartName,
                titleFontSize,
                animation: true,
            },
            createdAt: new Date(),
            updatedAt: new Date(),
        };
        saveChart(chartConfig);
        router.push("/charts");
    };

    // Filter tables for dropdown
    const filteredTables = tables.filter(
        (table) =>
            table.name.toLowerCase().includes(tableSearchQuery.toLowerCase()) ||
            table.schema.toLowerCase().includes(tableSearchQuery.toLowerCase())
    );

    // Numeric columns for Y axis
    const numericColumns = columns.filter((col) =>
        ["int", "bigint", "decimal", "numeric", "float", "real", "money", "smallmoney", "smallint", "tinyint"].includes(
            col.type.toLowerCase()
        )
    );

    // Build preview config
    const previewConfig: ChartConfig = {
        id: "preview",
        name: chartName || "Xem trước",
        type: currentChart.type || "bar",
        dataSource: {
            table: selectedTable,
            xAxis: selectedXAxis || "thang",
            yAxis: selectedYAxis.length > 0 ? selectedYAxis : ["ptm"],
            aggregation,
        },
        style: {
            colors: defaultChartColors,
            showLegend,
            legendPosition,
            showGrid,
            showTooltip: true,
            showDataLabels,
            xAxisLabel,
            yAxisLabel,
            title: chartName || undefined,
            titleFontSize,
            animation: true,
        },
        createdAt: new Date(),
        updatedAt: new Date(),
    };

    return (
        <>
            <Header
                title="Thiết kế biểu đồ"
                subtitle="Tạo biểu đồ mới"
                showDatePicker={false}
                showSearch={false}
                actions={
                    <div className="flex items-center gap-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => router.push("/charts")}
                            className="gap-2"
                        >
                            <ArrowLeft className="h-4 w-4" />
                            Quay lại
                        </Button>
                        <Button size="sm" onClick={handleSaveChart} className="gap-2">
                            <Save className="h-4 w-4" />
                            Lưu biểu đồ
                        </Button>
                    </div>
                }
            />

            <div className="flex-1 flex overflow-hidden">
                {/* Left Panel - Configuration */}
                <div className="w-80 flex-shrink-0 bg-white border-r border-[#E2E8F0] overflow-y-auto">
                    {/* Tabs */}
                    <div className="flex border-b border-[#E2E8F0]">
                        <button
                            onClick={() => setActiveTab("data")}
                            className={cn(
                                "flex-1 px-4 py-3 text-sm font-medium flex items-center justify-center gap-2 transition-colors",
                                activeTab === "data"
                                    ? "text-[#0052CC] border-b-2 border-[#0052CC]"
                                    : "text-[#64748B] hover:text-[#0F172A]"
                            )}
                        >
                            <Database className="h-4 w-4" />
                            Dữ liệu
                        </button>
                        <button
                            onClick={() => setActiveTab("style")}
                            className={cn(
                                "flex-1 px-4 py-3 text-sm font-medium flex items-center justify-center gap-2 transition-colors",
                                activeTab === "style"
                                    ? "text-[#0052CC] border-b-2 border-[#0052CC]"
                                    : "text-[#64748B] hover:text-[#0F172A]"
                            )}
                        >
                            <Palette className="h-4 w-4" />
                            Kiểu dáng
                        </button>
                    </div>

                    <div className="p-6 space-y-6">
                        {activeTab === "data" ? (
                            <>
                                {/* Chart Name */}
                                <div>
                                    <label className="text-sm font-semibold text-[#0F172A] mb-2 block">
                                        Tên biểu đồ
                                    </label>
                                    <Input
                                        placeholder="VD: Doanh thu theo tháng"
                                        value={chartName}
                                        onChange={(e) => setChartName(e.target.value)}
                                    />
                                </div>

                                {/* Chart Type */}
                                <div>
                                    <label className="text-sm font-semibold text-[#0F172A] mb-3 block">
                                        Loại biểu đồ
                                    </label>
                                    <div className="grid grid-cols-5 gap-2">
                                        {chartTypes.map(({ type, label, icon }) => (
                                            <button
                                                key={type}
                                                onClick={() => updateChartType(type)}
                                                title={label}
                                                className={cn(
                                                    "flex flex-col items-center gap-1 p-2 rounded-lg border transition-all",
                                                    currentChart.type === type
                                                        ? "border-[#0052CC] bg-[#0052CC]/5 text-[#0052CC]"
                                                        : "border-[#E2E8F0] hover:border-[#0052CC]/50 text-[#64748B]"
                                                )}
                                            >
                                                {icon}
                                                <span className="text-[10px] font-medium truncate w-full text-center">{label}</span>
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                {/* Data Source */}
                                <div>
                                    <div className="flex items-center gap-2 mb-3">
                                        <Database className="h-4 w-4 text-[#64748B]" />
                                        <label className="text-sm font-semibold text-[#0F172A]">
                                            Nguồn dữ liệu
                                        </label>
                                    </div>

                                    <div className="space-y-4">
                                        {/* Searchable Table Selection */}
                                        <div>
                                            <label className="text-xs text-[#64748B] mb-1 block">Bảng dữ liệu</label>
                                            <div className="relative" ref={tableDropdownRef}>
                                                <div className="relative">
                                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#94A3B8]" />
                                                    <Input
                                                        placeholder="Tìm và chọn bảng..."
                                                        value={tableSearchQuery}
                                                        onChange={(e) => {
                                                            setTableSearchQuery(e.target.value);
                                                            setShowTableDropdown(true);
                                                        }}
                                                        onFocus={() => setShowTableDropdown(true)}
                                                        className="pl-9 pr-8"
                                                    />
                                                    {isLoadingTables ? (
                                                        <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#94A3B8] animate-spin" />
                                                    ) : (
                                                        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#94A3B8]" />
                                                    )}
                                                </div>

                                                {showTableDropdown && (
                                                    <div className="absolute z-50 w-full mt-1 bg-white border border-[#E2E8F0] rounded-md shadow-lg max-h-60 overflow-y-auto">
                                                        {filteredTables.length === 0 ? (
                                                            <div className="p-3 text-sm text-[#64748B] text-center">
                                                                {isLoadingTables ? "Đang tải..." : "Không tìm thấy bảng"}
                                                            </div>
                                                        ) : (
                                                            filteredTables.map((table) => (
                                                                <button
                                                                    key={`${table.schema}.${table.name}`}
                                                                    onClick={() => handleTableSelect(table.name)}
                                                                    className={cn(
                                                                        "w-full text-left px-3 py-2 hover:bg-[#F8FAFC] transition-colors",
                                                                        selectedTable === table.name && "bg-[#0052CC]/5 text-[#0052CC]"
                                                                    )}
                                                                >
                                                                    <div className="text-sm font-medium">{table.name}</div>
                                                                    <div className="text-xs text-[#94A3B8]">
                                                                        {table.schema} • {table.rowCount?.toLocaleString() || 0} dòng
                                                                    </div>
                                                                </button>
                                                            ))
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                            {selectedTable && (
                                                <p className="text-xs text-[#0052CC] mt-1">
                                                    Đã chọn: {selectedTable}
                                                </p>
                                            )}
                                        </div>

                                        {/* X-Axis */}
                                        <div>
                                            <label className="text-xs text-[#64748B] mb-1 block">
                                                Trục X (Danh mục)
                                            </label>
                                            <Select
                                                value={selectedXAxis}
                                                onValueChange={handleXAxisChange}
                                                disabled={columns.length === 0}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue placeholder={isLoadingColumns ? "Đang tải..." : "Chọn cột"} />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {columns.map((col) => (
                                                        <SelectItem key={col.name} value={col.name}>
                                                            {col.name} ({col.type})
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        {/* Y-Axis (Multiple) */}
                                        <div>
                                            <label className="text-xs text-[#64748B] mb-2 block">
                                                Trục Y (Giá trị số) - Chọn nhiều
                                            </label>
                                            <div className="max-h-40 overflow-y-auto space-y-1 border border-[#E2E8F0] rounded-md p-2">
                                                {isLoadingColumns ? (
                                                    <div className="flex items-center justify-center py-4">
                                                        <Loader2 className="h-5 w-5 text-[#0052CC] animate-spin" />
                                                    </div>
                                                ) : numericColumns.length === 0 ? (
                                                    <p className="text-xs text-[#64748B] text-center py-2">
                                                        {columns.length === 0 ? "Chọn bảng trước" : "Không có cột số"}
                                                    </p>
                                                ) : (
                                                    numericColumns.map((col) => (
                                                        <label
                                                            key={col.name}
                                                            className="flex items-center gap-2 p-2 rounded hover:bg-[#F8FAFC] cursor-pointer"
                                                        >
                                                            <input
                                                                type="checkbox"
                                                                checked={selectedYAxis.includes(col.name)}
                                                                onChange={() => handleYAxisToggle(col.name)}
                                                                className="rounded border-[#E2E8F0] text-[#0052CC] focus:ring-[#0052CC]"
                                                            />
                                                            <span className="text-sm text-[#0F172A]">{col.name}</span>
                                                            <span className="text-xs text-[#94A3B8]">({col.type})</span>
                                                        </label>
                                                    ))
                                                )}
                                            </div>
                                        </div>

                                        {/* Aggregation */}
                                        <div>
                                            <label className="text-xs text-[#64748B] mb-1 block">
                                                Phép tính
                                            </label>
                                            <Select
                                                value={aggregation}
                                                onValueChange={(v) => setAggregation(v as any)}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="sum">SUM (Tổng)</SelectItem>
                                                    <SelectItem value="avg">AVG (Trung bình)</SelectItem>
                                                    <SelectItem value="count">COUNT (Đếm)</SelectItem>
                                                    <SelectItem value="min">MIN (Nhỏ nhất)</SelectItem>
                                                    <SelectItem value="max">MAX (Lớn nhất)</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        {/* Sorting */}
                                        <div className="grid grid-cols-2 gap-2">
                                            <div>
                                                <label className="text-xs text-[#64748B] mb-1 block">Sắp xếp theo</label>
                                                <Select value={orderBy} onValueChange={setOrderBy}>
                                                    <SelectTrigger><SelectValue placeholder="Trục..." /></SelectTrigger>
                                                    <SelectContent>
                                                        {columns.map(col => (
                                                            <SelectItem key={col.name} value={col.name}>{col.name}</SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div>
                                                <label className="text-xs text-[#64748B] mb-1 block">Thứ tự</label>
                                                <Select value={orderDirection} onValueChange={(v: "asc" | "desc") => setOrderDirection(v)}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="asc">Tăng dần</SelectItem>
                                                        <SelectItem value="desc">Giảm dần</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </>
                        ) : (
                            <>
                                {/* Style Options */}
                                <div>
                                    <div className="flex items-center gap-2 mb-4">
                                        <Settings2 className="h-4 w-4 text-[#64748B]" />
                                        <label className="text-sm font-semibold text-[#0F172A]">
                                            Tùy chỉnh hiển thị
                                        </label>
                                    </div>

                                    <div className="space-y-4">
                                        {/* Axis Labels */}
                                        <div className="space-y-3">
                                            <div>
                                                <label className="text-xs text-[#64748B] mb-1 block">Nhãn trục X</label>
                                                <Input
                                                    placeholder="VD: Thời gian"
                                                    value={xAxisLabel}
                                                    onChange={(e) => setXAxisLabel(e.target.value)}
                                                />
                                            </div>
                                            <div>
                                                <label className="text-xs text-[#64748B] mb-1 block">Nhãn trục Y</label>
                                                <Input
                                                    placeholder="VD: Doanh thu (vnđ)"
                                                    value={yAxisLabel}
                                                    onChange={(e) => setYAxisLabel(e.target.value)}
                                                />
                                            </div>
                                        </div>


                                        {/* Title Font Size */}
                                        <div>
                                            <label className="text-xs text-[#64748B] mb-1 block">
                                                Cỡ chữ tiêu đề
                                            </label>
                                            <Select
                                                value={titleFontSize.toString()}
                                                onValueChange={(v) => setTitleFontSize(parseInt(v))}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="12">12px (Nhỏ)</SelectItem>
                                                    <SelectItem value="14">14px (Mặc định)</SelectItem>
                                                    <SelectItem value="16">16px (Vừa)</SelectItem>
                                                    <SelectItem value="18">18px (Lớn)</SelectItem>
                                                    <SelectItem value="20">20px (Rất lớn)</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        {/* Legend Toggle */}
                                        <div className="flex items-center justify-between">
                                            <label className="text-sm text-[#0F172A]">Hiển thị chú thích</label>
                                            <button
                                                onClick={() => setShowLegend(!showLegend)}
                                                className={cn(
                                                    "w-10 h-6 rounded-full transition-colors relative",
                                                    showLegend ? "bg-[#0052CC]" : "bg-[#E2E8F0]"
                                                )}
                                            >
                                                <span
                                                    className={cn(
                                                        "absolute top-1 w-4 h-4 rounded-full bg-white transition-transform",
                                                        showLegend ? "right-1" : "left-1"
                                                    )}
                                                />
                                            </button>
                                        </div>

                                        {/* Legend Position */}
                                        {showLegend && (
                                            <div>
                                                <label className="text-xs text-[#64748B] mb-1 block">
                                                    Vị trí chú thích
                                                </label>
                                                <Select
                                                    value={legendPosition}
                                                    onValueChange={(v) => setLegendPosition(v as "top" | "bottom" | "left" | "right")}
                                                >
                                                    <SelectTrigger>
                                                        <SelectValue />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="top">Trên</SelectItem>
                                                        <SelectItem value="bottom">Dưới</SelectItem>
                                                        <SelectItem value="left">Trái</SelectItem>
                                                        <SelectItem value="right">Phải</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        )}

                                        {/* Grid Toggle */}
                                        <div className="flex items-center justify-between">
                                            <label className="text-sm text-[#0F172A]">Hiển thị lưới</label>
                                            <button
                                                onClick={() => setShowGrid(!showGrid)}
                                                className={cn(
                                                    "w-10 h-6 rounded-full transition-colors relative",
                                                    showGrid ? "bg-[#0052CC]" : "bg-[#E2E8F0]"
                                                )}
                                            >
                                                <span
                                                    className={cn(
                                                        "absolute top-1 w-4 h-4 rounded-full bg-white transition-transform",
                                                        showGrid ? "right-1" : "left-1"
                                                    )}
                                                />
                                            </button>
                                        </div>

                                        {/* Data Labels Toggle */}
                                        <div className="flex items-center justify-between">
                                            <label className="text-sm text-[#0F172A]">Hiển thị nhãn dữ liệu</label>
                                            <button
                                                onClick={() => setShowDataLabels(!showDataLabels)}
                                                className={cn(
                                                    "w-10 h-6 rounded-full transition-colors relative",
                                                    showDataLabels ? "bg-[#0052CC]" : "bg-[#E2E8F0]"
                                                )}
                                            >
                                                <span
                                                    className={cn(
                                                        "absolute top-1 w-4 h-4 rounded-full bg-white transition-transform",
                                                        showDataLabels ? "right-1" : "left-1"
                                                    )}
                                                />
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                {/* Color Palette Preview */}
                                <div>
                                    <label className="text-sm font-semibold text-[#0F172A] mb-3 block">
                                        Bảng màu
                                    </label>
                                    <div className="flex gap-2 flex-wrap">
                                        {defaultChartColors.map((color, index) => (
                                            <div
                                                key={index}
                                                className="w-8 h-8 rounded-lg border border-[#E2E8F0]"
                                                style={{ backgroundColor: color }}
                                                title={color}
                                            />
                                        ))}
                                    </div>
                                </div>
                            </>
                        )}
                    </div>
                </div>

                {/* Right Panel - Preview */}
                <div className="flex-1 overflow-y-auto p-6 bg-[#F8FAFC]">
                    <Card className="h-full">
                        <CardHeader>
                            <CardTitle className="text-lg">
                                {chartName || "Xem trước biểu đồ"}
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="h-[400px]">
                                {isLoadingChartData ? (
                                    <div className="flex items-center justify-center h-full">
                                        <Loader2 className="h-8 w-8 text-[#0052CC] animate-spin" />
                                        <span className="ml-2 text-[#64748B]">Đang tải dữ liệu...</span>
                                    </div>
                                ) : chartDataError ? (
                                    <div className="flex flex-col items-center justify-center h-full text-center">
                                        <p className="text-red-500 mb-2">{chartDataError}</p>
                                        <Button variant="outline" size="sm" onClick={fetchChartData}>
                                            Thử lại
                                        </Button>
                                    </div>
                                ) : chartData.length === 0 ? (
                                    <div className="flex flex-col items-center justify-center h-full text-center text-[#64748B]">
                                        <Database className="h-12 w-12 mb-4 text-[#94A3B8]" />
                                        <p>Chọn bảng, trục X và trục Y để xem biểu đồ</p>
                                    </div>
                                ) : (
                                    <DynamicChart config={previewConfig} data={chartData} height={380} />
                                )}
                            </div>

                            {/* Selected Configuration Summary */}
                            <div className="mt-6 p-4 bg-[#F8FAFC] rounded-lg border border-[#E2E8F0]">
                                <h4 className="text-sm font-semibold text-[#0F172A] mb-3">
                                    Cấu hình đã chọn
                                </h4>
                                <div className="grid grid-cols-2 gap-4 text-sm">
                                    <div>
                                        <span className="text-[#64748B]">Bảng:</span>{" "}
                                        <span className="font-medium text-[#0F172A]">
                                            {selectedTable || "(chưa chọn)"}
                                        </span>
                                    </div>
                                    <div>
                                        <span className="text-[#64748B]">Loại:</span>{" "}
                                        <span className="font-medium text-[#0F172A] capitalize">
                                            {currentChart.type || "bar"}
                                        </span>
                                    </div>
                                    <div>
                                        <span className="text-[#64748B]">Trục X:</span>{" "}
                                        <span className="font-medium text-[#0F172A]">
                                            {selectedXAxis || "(chưa chọn)"}
                                        </span>
                                    </div>
                                    <div>
                                        <span className="text-[#64748B]">Trục Y:</span>{" "}
                                        <span className="font-medium text-[#0F172A]">
                                            {selectedYAxis.length > 0 ? selectedYAxis.join(", ") : "(chưa chọn)"}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </>
    );
}
