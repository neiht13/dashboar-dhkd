import sql from 'mssql';

const config: sql.config = {
    server: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'sa',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'master',
    port: parseInt(process.env.DB_PORT || '1433'),
    options: {
        encrypt: process.env.DB_ENCRYPT === 'true',
        trustServerCertificate: true,
    },
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000,
    },
    requestTimeout: 60000, // 60 seconds
    connectionTimeout: 30000, // 30 seconds
};

let pool: sql.ConnectionPool | null = null;

export async function getPool(): Promise<sql.ConnectionPool> {
    if (!pool) {
        pool = await sql.connect(config);
    }
    return pool;
}

export async function executeQuery<T>(query: string, params?: Record<string, unknown>): Promise<T[]> {
    const pool = await getPool();
    const request = pool.request();

    if (params) {
        Object.entries(params).forEach(([key, value]) => {
            request.input(key, value);
        });
    }

    const result = await request.query(query);
    return result.recordset as T[];
}

export async function testConnection(): Promise<boolean> {
    try {
        const pool = await getPool();
        await pool.request().query('SELECT 1');
        return true;
    } catch (error) {
        console.error('Database connection failed:', error);
        return false;
    }
}

// Close pool when the app is shutting down
process.on('beforeExit', async () => {
    if (pool) {
        await pool.close();
        pool = null;
    }
});
