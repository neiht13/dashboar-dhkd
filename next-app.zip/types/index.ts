// Database Types
export interface TableInfo {
  schema: string;
  name: string;
  rowCount: number;
}

export interface ColumnInfo {
  name: string;
  type: string;
  nullable: string;
  isPrimaryKey?: boolean;
}

export interface DatabaseSchema {
  tables: TableInfo[];
}

// Chart Types - Extended with new chart types
export type ChartType =
  | 'line'
  | 'bar'
  | 'area'
  | 'pie'
  | 'radar'
  | 'scatter'
  | 'heatmap'
  | 'donut'
  | 'stackedBar'
  | 'horizontalBar'
  | 'composed'
  | 'funnel';

export type AggregationType = 'sum' | 'avg' | 'count' | 'min' | 'max' | 'none';

export interface Filter {
  field: string;
  operator: '=' | '!=' | '>' | '<' | '>=' | '<=' | 'like' | 'in';
  value: string | number | string[] | number[];
}

export interface DataSource {
  table: string;
  xAxis: string;
  yAxis: string[];
  groupBy?: string;
  aggregation: AggregationType;
  filters?: Filter[];
  orderBy?: string;
  orderDirection?: 'asc' | 'desc';
  limit?: number;
}

// Extended Chart Style with new customization options
export interface ChartStyle {
  colors: string[];
  showLegend: boolean;
  legendPosition?: 'top' | 'bottom' | 'left' | 'right';
  showGrid: boolean;
  showTooltip: boolean;
  showDataLabels?: boolean;
  dataLabelPosition?: 'inside' | 'outside' | 'center';
  title?: string;
  titleFontSize?: number;
  titleColor?: string;
  xAxisLabel?: string;
  yAxisLabel?: string;
  stacked?: boolean;
  horizontal?: boolean;
  innerRadius?: number; // for donut chart (0-100 percentage)
  animation?: boolean;
  gradientFill?: boolean;
  borderRadius?: number;
}

export interface ChartConfig {
  id: string;
  name: string;
  type: ChartType;
  dataSource: DataSource;
  style: ChartStyle;
  createdAt: Date;
  updatedAt: Date;
  userId?: string;
}

// Dashboard Types
export interface LayoutItem {
  i: string;       // widget id
  x: number;       // 0-11 (12 columns)
  y: number;       // row position
  w: number;       // width in columns (1-12)
  h: number;       // height in rows
  minW?: number;
  minH?: number;
  maxW?: number;
  maxH?: number;
  static?: boolean;
}

export type WidgetType = 'chart' | 'kpi' | 'table' | 'text';

export interface KPIConfig {
  table: string;
  field: string;
  aggregation: AggregationType;
  title: string;
  format?: 'number' | 'currency' | 'percent';
  compareWithPrevious?: boolean;
  color?: string;
  icon?: string;
}

export interface TableWidgetConfig {
  table: string;
  columns: string[];
  pageSize?: number;
  showPagination?: boolean;
}

export interface TextWidgetConfig {
  content: string;
  fontSize?: number;
  textAlign?: 'left' | 'center' | 'right';
}

export interface Widget {
  id: string;
  type: WidgetType;
  config: ChartConfig | KPIConfig | TableWidgetConfig | TextWidgetConfig;
  layout: LayoutItem;
}

export interface DashboardTab {
  id: string;
  name: string;
  widgets: Widget[];
  layout: LayoutItem[];
}

export interface Dashboard {
  id: string;
  name: string;
  description?: string;
  widgets: Widget[];
  layout: LayoutItem[];
  tabs?: DashboardTab[];
  activeTabId?: string;
  createdAt: Date;
  updatedAt: Date;
  userId?: string;
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

// User Types
export interface User {
  id: string;
  email: string;
  name?: string;
  role: 'admin' | 'editor' | 'viewer' | 'user';
  createdAt: Date;
}
