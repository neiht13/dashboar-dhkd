"use client";

import React from "react";
import { Bell, Search, Calendar, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface HeaderProps {
    title: string;
    subtitle?: string;
    showDatePicker?: boolean;
    showSearch?: boolean;
    actions?: React.ReactNode;
}

export function Header({
    title,
    subtitle,
    showDatePicker = true,
    showSearch = true,
    actions,
}: HeaderProps) {
    return (
        <header className="flex-shrink-0 flex items-center justify-between px-8 py-4 border-b border-[#E2E8F0] bg-white shadow-sm">
            <div className="flex items-center gap-6">
                <div>
                    <h2 className="text-xl font-bold text-[#0F172A] tracking-tight">
                        {title}
                        {subtitle && (
                            <span className="text-[#94A3B8] font-medium ml-2">{subtitle}</span>
                        )}
                    </h2>
                </div>

                {showDatePicker && (
                    <>
                        <div className="h-6 w-px bg-[#E2E8F0]" />
                        <Button
                            variant="outline"
                            size="sm"
                            className="flex items-center gap-2 text-xs font-medium"
                        >
                            <Calendar className="h-4 w-4" />
                            <span>30 ngày qua</span>
                            <ChevronDown className="h-3 w-3 text-[#94A3B8]" />
                        </Button>
                    </>
                )}
            </div>

            <div className="flex items-center gap-4">
                {/* Custom Actions */}
                {actions}

                {/* Search */}
                {showSearch && (
                    <div className="relative hidden md:block">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#94A3B8]" />
                        <Input
                            placeholder="Search..."
                            className="w-64 pl-9 h-9 bg-[#F8FAFC] border-[#E2E8F0]"
                        />
                    </div>
                )}

                <div className="h-6 w-px bg-[#E2E8F0] mx-2" />

                {/* Notifications */}
                <Button
                    variant="ghost"
                    size="icon"
                    className="relative rounded-full bg-[#F8FAFC] hover:bg-[#F1F5F9] border border-[#E2E8F0]"
                >
                    <span className="absolute -top-0.5 -right-0.5 size-2.5 bg-[#D10029] rounded-full border-2 border-white" />
                    <Bell className="h-4 w-4 text-[#64748B]" />
                </Button>

                {/* Search Button (Mobile) */}
                <Button
                    variant="ghost"
                    size="icon"
                    className="md:hidden rounded-full bg-[#F8FAFC] hover:bg-[#F1F5F9] border border-[#E2E8F0]"
                >
                    <Search className="h-4 w-4 text-[#64748B]" />
                </Button>
            </div>
        </header>
    );
}
