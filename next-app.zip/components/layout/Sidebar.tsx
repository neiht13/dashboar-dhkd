"use client";

import React, { useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import { useAuthStore } from "@/stores/auth-store";
import {
    LayoutDashboard,
    BarChart3,
    Database,
    Settings,
    PlusCircle,
    FolderKanban,
    Activity,
    LogOut,
    User,
} from "lucide-react";

interface NavItem {
    title: string;
    href: string;
    icon: React.ReactNode;
}

const mainNavItems: NavItem[] = [
    {
        title: "Bảng điều khiển",
        href: "/",
        icon: <LayoutDashboard className="h-[18px] w-[18px]" />,
    },
    {
        title: "Thiết kế biểu đồ",
        href: "/charts/new",
        icon: <BarChart3 className="h-[18px] w-[18px]" />,
    },
    {
        title: "Biểu đồ của tôi",
        href: "/charts",
        icon: <FolderKanban className="h-[18px] w-[18px]" />,
    },
    {
        title: "Cơ sở dữ liệu",
        href: "/database",
        icon: <Database className="h-[18px] w-[18px]" />,
    },
];

const bottomNavItems: NavItem[] = [
    {
        title: "Cài đặt",
        href: "/settings",
        icon: <Settings className="h-[18px] w-[18px]" />,
    },
];

export function Sidebar() {
    const pathname = usePathname();
    const router = useRouter();
    const { user, isAuthenticated, logout, checkAuth } = useAuthStore();

    useEffect(() => {
        checkAuth();
    }, [checkAuth]);

    const handleLogout = async () => {
        await logout();
        router.push("/login");
    };

    return (
        <aside className="w-[240px] flex-shrink-0 bg-white border-r border-[#E2E8F0] flex flex-col justify-between h-screen sticky top-0">
            <div>
                {/* Logo */}
                <div className="flex items-center gap-3 px-5 py-5 border-b border-[#E2E8F0]">
                    <div className="size-9 bg-gradient-to-br from-[#0066FF] to-[#0052CC] flex items-center justify-center shadow-md" style={{ borderRadius: '4px' }}>
                        <Activity className="h-5 w-5 text-white" />
                    </div>
                    <h1 className="text-base font-bold tracking-tight text-[#0F172A]">
                        NEXUS<span className="text-[#0066FF]">.</span>
                    </h1>
                </div>

                {/* Main Navigation */}
                <nav className="flex flex-col mt-5 px-3 gap-0.5 stagger-children">
                    {mainNavItems.map((item) => {
                        const isActive = pathname === item.href ||
                            (item.href !== "/" && pathname.startsWith(item.href));

                        return (
                            <Link
                                key={item.href}
                                href={item.href}
                                className={cn(
                                    "flex items-center gap-3 px-3 py-2.5 text-[13px] font-medium transition-all",
                                    isActive
                                        ? "bg-[#0066FF] text-white shadow-sm"
                                        : "text-[#64748B] hover:bg-[#F1F5F9] hover:text-[#0F172A]"
                                )}
                                style={{ borderRadius: '4px' }}
                            >
                                {item.icon}
                                <span>{item.title}</span>
                            </Link>
                        );
                    })}

                    {/* Create New Dashboard Button */}
                    <Link
                        href="/builder/new"
                        className="flex items-center gap-3 px-3 py-2.5 mt-4 text-[13px] font-medium bg-[#0F172A] text-white hover:bg-[#1E293B] transition-all"
                        style={{ borderRadius: '4px' }}
                    >
                        <PlusCircle className="h-[18px] w-[18px]" />
                        <span>Dashboard Mới</span>
                    </Link>
                </nav>

                {/* System Status */}
                <div className="px-5 mt-8">
                    <h3 className="text-[10px] font-bold text-[#94A3B8] uppercase tracking-widest mb-3">
                        Trạng thái
                    </h3>
                    <div className="space-y-2">
                        <div className="flex items-center gap-2 text-[12px] text-[#64748B]">
                            <div className="size-1.5 bg-emerald-500" style={{ borderRadius: '1px' }} />
                            <span>SQL Server</span>
                        </div>
                        <div className="flex items-center gap-2 text-[12px] text-[#64748B]">
                            <div className="size-1.5 bg-emerald-500" style={{ borderRadius: '1px' }} />
                            <span>MongoDB</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Bottom Navigation */}
            <div className="p-3 border-t border-[#E2E8F0]">
                {bottomNavItems.map((item) => {
                    const isActive = pathname === item.href;

                    return (
                        <Link
                            key={item.href}
                            href={item.href}
                            className={cn(
                                "flex items-center gap-3 px-3 py-2.5 text-[13px] font-medium transition-all",
                                isActive
                                    ? "bg-[#F1F5F9] text-[#0066FF]"
                                    : "text-[#64748B] hover:bg-[#F1F5F9] hover:text-[#0F172A]"
                            )}
                            style={{ borderRadius: '4px' }}
                        >
                            {item.icon}
                            <span>{item.title}</span>
                        </Link>
                    );
                })}

                {/* User Profile */}
                {isAuthenticated && user ? (
                    <div className="mt-3 p-3 bg-[#F8FAFC] border border-[#E2E8F0]" style={{ borderRadius: '4px' }}>
                        <div className="flex items-center gap-3">
                            <div className="size-8 bg-gradient-to-br from-[#0066FF] to-[#8B5CF6] flex items-center justify-center text-white font-bold text-xs" style={{ borderRadius: '4px' }}>
                                {user.name?.charAt(0).toUpperCase() || 'U'}
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className="text-[13px] font-semibold text-[#0F172A] truncate">{user.name}</p>
                                <p className="text-[10px] text-[#0066FF] uppercase font-bold tracking-wider">
                                    {user.role}
                                </p>
                            </div>
                        </div>
                        <button
                            onClick={handleLogout}
                            className="flex items-center gap-2 w-full mt-3 px-2 py-1.5 text-[11px] font-medium text-[#64748B] hover:text-[#EF4444] hover:bg-[#FEE2E2] transition-all"
                            style={{ borderRadius: '3px' }}
                        >
                            <LogOut className="h-3.5 w-3.5" />
                            <span>Đăng xuất</span>
                        </button>
                    </div>
                ) : (
                    <Link
                        href="/login"
                        className="flex items-center gap-3 mt-3 p-3 bg-[#F8FAFC] border border-[#E2E8F0] text-[#64748B] hover:text-[#0066FF] hover:border-[#0066FF] transition-all"
                        style={{ borderRadius: '4px' }}
                    >
                        <User className="h-[18px] w-[18px]" />
                        <span className="text-[13px] font-medium">Đăng nhập</span>
                    </Link>
                )}
            </div>
        </aside>
    );
}
