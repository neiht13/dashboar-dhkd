"use client";

import React from "react";
import {
    LineChart,
    Line,
    BarChart,
    Bar,
    AreaChart,
    Area,
    PieChart,
    Pie,
    Cell,
    RadarChart,
    Radar,
    PolarGrid,
    PolarAngleAxis,
    PolarRadiusAxis,
    ScatterChart,
    Scatter,
    ComposedChart,
    FunnelChart,
    Funnel,
    LabelList,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer,
    Label,
} from "recharts";
import type { ChartConfig } from "@/types";
import { getChartColor } from "@/lib/utils";

interface DynamicChartProps {
    config: ChartConfig;
    data: Record<string, unknown>[];
    width?: number;
    height?: number;
}

// Vietnamese labels for legend and tooltip
const VI_LABELS: Record<string, string> = {
    ptm: "Phát triển mới",
    khoiphuc: "Khôi phục",
    thanhly: "Thanh lý",
    tamngung_yc: "Tạm ngưng YC",
    tamngung_nc: "Tạm ngưng NC",
    dichchuyen: "Dịch chuyển",
    quahan: "Quá hạn",
    dungthu: "Dùng thử",
    dungthat: "Dùng thật",
    value: "Giá trị",
    name: "Tên",
};

const getLabel = (key: string): string => VI_LABELS[key] || key;

// Modern color palette with gradients
const MODERN_COLORS = [
    "#0066FF", // Primary Blue
    "#8B5CF6", // Purple
    "#10B981", // Emerald
    "#F59E0B", // Amber
    "#EF4444", // Red
    "#06B6D4", // Cyan
    "#EC4899", // Pink
    "#14B8A6", // Teal
];

// Custom Tooltip Component
const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) => {
    if (!active || !payload?.length) return null;

    return (
        <div className="bg-[#0F172A] text-white px-3 py-2 shadow-xl border-0" style={{ borderRadius: '4px' }}>
            <p className="text-xs font-medium text-[#94A3B8] mb-1">{label}</p>
            {payload.map((entry, index) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                    <span
                        className="w-2 h-2"
                        style={{ backgroundColor: entry.color, borderRadius: '2px' }}
                    />
                    <span className="text-[#E2E8F0]">{getLabel(entry.name)}:</span>
                    <span className="font-semibold">{typeof entry.value === 'number' ? entry.value.toLocaleString() : entry.value}</span>
                </div>
            ))}
        </div>
    );
};

// Custom Legend Component
const CustomLegend = ({ payload }: { payload?: Array<{ value: string; color: string }> }) => {
    if (!payload?.length) return null;

    return (
        <div className="flex flex-wrap justify-center gap-4 mt-4">
            {payload.map((entry, index) => (
                <div key={index} className="flex items-center gap-2 text-xs">
                    <span
                        className="w-3 h-3"
                        style={{ backgroundColor: entry.color, borderRadius: '2px' }}
                    />
                    <span className="text-[#64748B] font-medium">{getLabel(entry.value)}</span>
                </div>
            ))}
        </div>
    );
};

export function DynamicChart({ config, data, height = 300 }: DynamicChartProps) {
    const { type, dataSource, style } = config;
    const colors = style?.colors?.length ? style.colors : MODERN_COLORS;
    const showDataLabels = style?.showDataLabels ?? false;

    // Animation config
    const animationProps = {
        isAnimationActive: style?.animation !== false,
        animationDuration: 800,
        animationEasing: "ease-out" as const,
    };

    const renderChart = () => {
        switch (type) {
            case "line":
                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <LineChart data={data} margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
                            <defs>
                                {dataSource.yAxis.map((field, index) => (
                                    <linearGradient key={field} id={`line-gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor={colors[index] || getChartColor(index)} stopOpacity={0.8} />
                                        <stop offset="100%" stopColor={colors[index] || getChartColor(index)} stopOpacity={0.3} />
                                    </linearGradient>
                                ))}
                            </defs>
                            {style?.showGrid && <CartesianGrid strokeDasharray="0" stroke="#E2E8F0" vertical={false} />}
                            <XAxis
                                dataKey={dataSource.xAxis}
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={{ stroke: "#E2E8F0" }}
                                tickLine={false}
                                height={style?.xAxisLabel ? 40 : 30}
                            >
                                {style?.xAxisLabel && <Label value={style.xAxisLabel} offset={-5} position="insideBottom" fill="#64748B" fontSize={12} />}
                            </XAxis>
                            <YAxis
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={false}
                                tickLine={false}
                                width={60}
                            >
                                {style?.yAxisLabel && <Label value={style.yAxisLabel} angle={-90} position="insideLeft" style={{ textAnchor: 'middle', fill: '#64748B', fontSize: 12 }} />}
                            </YAxis>
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            {dataSource.yAxis.map((field, index) => (
                                <Line
                                    key={field}
                                    type="monotone"
                                    dataKey={field}
                                    name={field}
                                    stroke={colors[index] || getChartColor(index)}
                                    strokeWidth={2.5}
                                    dot={{ fill: "#fff", stroke: colors[index] || getChartColor(index), strokeWidth: 2, r: 4 }}
                                    activeDot={{ r: 6, fill: colors[index] || getChartColor(index), stroke: "#fff", strokeWidth: 2 }}
                                    {...animationProps}
                                >
                                    {showDataLabels && <LabelList dataKey={field} position="top" fontSize={10} fill="#64748B" />}
                                </Line>
                            ))}
                        </LineChart>
                    </ResponsiveContainer>
                );

            case "bar":
                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <BarChart data={data} margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
                            <defs>
                                {dataSource.yAxis.map((field, index) => (
                                    <linearGradient key={field} id={`bar-gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor={colors[index] || getChartColor(index)} stopOpacity={1} />
                                        <stop offset="100%" stopColor={colors[index] || getChartColor(index)} stopOpacity={0.7} />
                                    </linearGradient>
                                ))}
                            </defs>
                            {style?.showGrid && <CartesianGrid strokeDasharray="0" stroke="#E2E8F0" vertical={false} />}
                            <XAxis
                                dataKey={dataSource.xAxis}
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={{ stroke: "#E2E8F0" }}
                                tickLine={false}
                                height={style?.xAxisLabel ? 40 : 30}
                            >
                                {style?.xAxisLabel && <Label value={style.xAxisLabel} offset={-5} position="insideBottom" fill="#64748B" fontSize={12} />}
                            </XAxis>
                            <YAxis
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={false}
                                tickLine={false}
                                width={60}
                            >
                                {style?.yAxisLabel && <Label value={style.yAxisLabel} angle={-90} position="insideLeft" style={{ textAnchor: 'middle', fill: '#64748B', fontSize: 12 }} />}
                            </YAxis>
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0, 102, 255, 0.05)' }} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            {dataSource.yAxis.map((field, index) => (
                                <Bar
                                    key={field}
                                    dataKey={field}
                                    name={field}
                                    fill={`url(#bar-gradient-${index})`}
                                    radius={[2, 2, 0, 0]}
                                    {...animationProps}
                                >
                                    {showDataLabels && <LabelList dataKey={field} position="top" fontSize={10} fill="#64748B" />}
                                </Bar>
                            ))}
                        </BarChart>
                    </ResponsiveContainer>
                );

            case "stackedBar":
                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <BarChart data={data} margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
                            <defs>
                                {dataSource.yAxis.map((field, index) => (
                                    <linearGradient key={field} id={`stacked-gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor={colors[index] || getChartColor(index)} stopOpacity={1} />
                                        <stop offset="100%" stopColor={colors[index] || getChartColor(index)} stopOpacity={0.8} />
                                    </linearGradient>
                                ))}
                            </defs>
                            {style?.showGrid && <CartesianGrid strokeDasharray="0" stroke="#E2E8F0" vertical={false} />}
                            <XAxis
                                dataKey={dataSource.xAxis}
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={{ stroke: "#E2E8F0" }}
                                tickLine={false}
                                height={style?.xAxisLabel ? 40 : 30}
                            >
                                {style?.xAxisLabel && <Label value={style.xAxisLabel} offset={-5} position="insideBottom" fill="#64748B" fontSize={12} />}
                            </XAxis>
                            <YAxis
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={false}
                                tickLine={false}
                                width={60}
                            >
                                {style?.yAxisLabel && <Label value={style.yAxisLabel} angle={-90} position="insideLeft" style={{ textAnchor: 'middle', fill: '#64748B', fontSize: 12 }} />}
                            </YAxis>
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0, 102, 255, 0.05)' }} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            {dataSource.yAxis.map((field, index) => (
                                <Bar
                                    key={field}
                                    dataKey={field}
                                    name={field}
                                    stackId="stack"
                                    fill={`url(#stacked-gradient-${index})`}
                                    {...animationProps}
                                >
                                    {showDataLabels && <LabelList dataKey={field} position="center" fill="#fff" fontSize={10} fontWeight={600} />}
                                </Bar>
                            ))}
                        </BarChart>
                    </ResponsiveContainer>
                );

            case "horizontalBar":
                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <BarChart data={data} layout="vertical" margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
                            <defs>
                                {dataSource.yAxis.map((field, index) => (
                                    <linearGradient key={field} id={`hbar-gradient-${index}`} x1="0" y1="0" x2="1" y2="0">
                                        <stop offset="0%" stopColor={colors[index] || getChartColor(index)} stopOpacity={0.7} />
                                        <stop offset="100%" stopColor={colors[index] || getChartColor(index)} stopOpacity={1} />
                                    </linearGradient>
                                ))}
                            </defs>
                            {style?.showGrid && <CartesianGrid strokeDasharray="0" stroke="#E2E8F0" horizontal={false} />}
                            <XAxis
                                type="number"
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={{ stroke: "#E2E8F0" }}
                                tickLine={false}
                            />
                            <YAxis
                                dataKey={dataSource.xAxis}
                                type="category"
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={false}
                                tickLine={false}
                                width={80}
                            />
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0, 102, 255, 0.05)' }} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            {dataSource.yAxis.map((field, index) => (
                                <Bar
                                    key={field}
                                    dataKey={field}
                                    name={field}
                                    fill={`url(#hbar-gradient-${index})`}
                                    radius={[0, 2, 2, 0]}
                                    {...animationProps}
                                >
                                    {showDataLabels && <LabelList dataKey={field} position="right" fontSize={10} fill="#64748B" />}
                                </Bar>
                            ))}
                        </BarChart>
                    </ResponsiveContainer>
                );

            case "area":
                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <AreaChart data={data} margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
                            <defs>
                                {dataSource.yAxis.map((field, index) => (
                                    <linearGradient key={field} id={`area-gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor={colors[index] || getChartColor(index)} stopOpacity={0.4} />
                                        <stop offset="100%" stopColor={colors[index] || getChartColor(index)} stopOpacity={0.05} />
                                    </linearGradient>
                                ))}
                            </defs>
                            {style?.showGrid && <CartesianGrid strokeDasharray="0" stroke="#E2E8F0" vertical={false} />}
                            <XAxis
                                dataKey={dataSource.xAxis}
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={{ stroke: "#E2E8F0" }}
                                tickLine={false}
                                height={style?.xAxisLabel ? 40 : 30}
                            >
                                {style?.xAxisLabel && <Label value={style.xAxisLabel} offset={-5} position="insideBottom" fill="#64748B" fontSize={12} />}
                            </XAxis>
                            <YAxis
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={false}
                                tickLine={false}
                                width={60}
                            >
                                {style?.yAxisLabel && <Label value={style.yAxisLabel} angle={-90} position="insideLeft" style={{ textAnchor: 'middle', fill: '#64748B', fontSize: 12 }} />}
                            </YAxis>
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            {dataSource.yAxis.map((field, index) => (
                                <Area
                                    key={field}
                                    type="monotone"
                                    dataKey={field}
                                    name={field}
                                    stroke={colors[index] || getChartColor(index)}
                                    strokeWidth={2}
                                    fill={`url(#area-gradient-${index})`}
                                    {...animationProps}
                                />
                            ))}
                        </AreaChart>
                    </ResponsiveContainer>
                );

            case "pie":
                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <PieChart>
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            <Pie
                                data={data}
                                dataKey={dataSource.yAxis[0]}
                                nameKey={dataSource.xAxis}
                                cx="50%"
                                cy="50%"
                                outerRadius={height / 3}
                                label={showDataLabels ? ({ percent }: { percent?: number }) => (percent ? `${(percent * 100).toFixed(0)}%` : '') : false}
                                labelLine={false}
                                {...animationProps}
                            >
                                {data.map((_, index) => (
                                    <Cell
                                        key={`cell-${index}`}
                                        fill={colors[index % colors.length] || getChartColor(index)}
                                        stroke="#fff"
                                        strokeWidth={2}
                                    />
                                ))}
                            </Pie>
                        </PieChart>
                    </ResponsiveContainer>
                );

            case "donut":
                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <PieChart>
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            <Pie
                                data={data}
                                dataKey={dataSource.yAxis[0]}
                                nameKey={dataSource.xAxis}
                                cx="50%"
                                cy="50%"
                                innerRadius={height / 5}
                                outerRadius={height / 3}
                                label={showDataLabels ? ({ percent }: { percent?: number }) => (percent ? `${(percent * 100).toFixed(0)}%` : '') : false}
                                labelLine={false}
                                paddingAngle={2}
                                {...animationProps}
                            >
                                {data.map((_, index) => (
                                    <Cell
                                        key={`cell-${index}`}
                                        fill={colors[index % colors.length] || getChartColor(index)}
                                        stroke="#fff"
                                        strokeWidth={2}
                                    />
                                ))}
                            </Pie>
                        </PieChart>
                    </ResponsiveContainer>
                );

            case "radar":
                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <RadarChart data={data}>
                            <PolarGrid stroke="#E2E8F0" />
                            <PolarAngleAxis
                                dataKey={dataSource.xAxis}
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                            />
                            <PolarRadiusAxis tick={{ fontSize: 10, fill: "#94A3B8" }} />
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            {dataSource.yAxis.map((field, index) => (
                                <Radar
                                    key={field}
                                    name={field}
                                    dataKey={field}
                                    stroke={colors[index] || getChartColor(index)}
                                    fill={colors[index] || getChartColor(index)}
                                    fillOpacity={0.25}
                                    strokeWidth={2}
                                    {...animationProps}
                                />
                            ))}
                        </RadarChart>
                    </ResponsiveContainer>
                );

            case "scatter":
                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <ScatterChart margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
                            {style?.showGrid && <CartesianGrid strokeDasharray="0" stroke="#E2E8F0" />}
                            <XAxis
                                dataKey={dataSource.xAxis}
                                name={dataSource.xAxis}
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={{ stroke: "#E2E8F0" }}
                                tickLine={false}
                            />
                            <YAxis
                                dataKey={dataSource.yAxis[0]}
                                name={dataSource.yAxis[0]}
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={false}
                                tickLine={false}
                                width={50}
                            />
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            <Scatter
                                data={data}
                                fill={colors[0] || getChartColor(0)}
                                {...animationProps}
                            />
                        </ScatterChart>
                    </ResponsiveContainer>
                );

            case "composed":
                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <ComposedChart data={data} margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
                            <defs>
                                {dataSource.yAxis.map((field, index) => (
                                    <linearGradient key={field} id={`composed-gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor={colors[index] || getChartColor(index)} stopOpacity={1} />
                                        <stop offset="100%" stopColor={colors[index] || getChartColor(index)} stopOpacity={0.7} />
                                    </linearGradient>
                                ))}
                            </defs>
                            {style?.showGrid && <CartesianGrid strokeDasharray="0" stroke="#E2E8F0" vertical={false} />}
                            <XAxis
                                dataKey={dataSource.xAxis}
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={{ stroke: "#E2E8F0" }}
                                tickLine={false}
                                height={style?.xAxisLabel ? 40 : 30}
                            >
                                {style?.xAxisLabel && <Label value={style.xAxisLabel} offset={-5} position="insideBottom" fill="#64748B" fontSize={12} />}
                            </XAxis>
                            <YAxis
                                tick={{ fontSize: 11, fill: "#64748B", fontWeight: 500 }}
                                axisLine={false}
                                tickLine={false}
                                width={60}
                            >
                                {style?.yAxisLabel && <Label value={style.yAxisLabel} angle={-90} position="insideLeft" style={{ textAnchor: 'middle', fill: '#64748B', fontSize: 12 }} />}
                            </YAxis>
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0, 102, 255, 0.05)' }} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            {dataSource.yAxis.map((field, index) => {
                                if (index % 2 === 0) {
                                    return (
                                        <Bar
                                            key={field}
                                            dataKey={field}
                                            name={field}
                                            fill={`url(#composed-gradient-${index})`}
                                            radius={[2, 2, 0, 0]}
                                            {...animationProps}
                                        />
                                    );
                                } else {
                                    return (
                                        <Line
                                            key={field}
                                            type="monotone"
                                            dataKey={field}
                                            name={field}
                                            stroke={colors[index] || getChartColor(index)}
                                            strokeWidth={2.5}
                                            dot={{ fill: "#fff", stroke: colors[index] || getChartColor(index), strokeWidth: 2, r: 4 }}
                                            {...animationProps}
                                        />
                                    );
                                }
                            })}
                        </ComposedChart>
                    </ResponsiveContainer>
                );

            case "funnel":
                const funnelData = data.map((item, index) => ({
                    name: item[dataSource.xAxis] as string,
                    value: item[dataSource.yAxis[0]] as number,
                    fill: colors[index % colors.length] || getChartColor(index),
                }));

                return (
                    <ResponsiveContainer width="100%" height={height}>
                        <FunnelChart>
                            {style?.showTooltip && <Tooltip content={<CustomTooltip />} />}
                            {style?.showLegend && <Legend content={<CustomLegend />} />}
                            <Funnel
                                dataKey="value"
                                data={funnelData}
                                {...animationProps}
                            >
                                {showDataLabels && <LabelList position="center" fill="#fff" stroke="none" dataKey="name" fontSize={11} fontWeight={600} />}
                            </Funnel>
                        </FunnelChart>
                    </ResponsiveContainer>
                );

            default:
                return (
                    <div className="flex items-center justify-center h-full text-[#64748B]">
                        Loại biểu đồ không được hỗ trợ: {type}
                    </div>
                );
        }
    };

    return (
        <div className="w-full h-full animate-fade-in">
            {style?.title && (
                <h3
                    className="font-semibold text-[#0F172A] mb-3"
                    style={{
                        fontSize: style.titleFontSize || 14,
                        color: style.titleColor || '#0F172A'
                    }}
                >
                    {style.title}
                </h3>
            )}
            {renderChart()}
        </div>
    );
}
