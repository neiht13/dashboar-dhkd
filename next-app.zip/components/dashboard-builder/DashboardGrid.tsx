"use client";

import React, { useState, useCallback, useEffect, useRef } from "react";
import { useDroppable } from "@dnd-kit/core";
import { useDashboardStore } from "@/stores/dashboard-store";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Move, GripVertical, Maximize2, BarChart3 } from "lucide-react";
import { DynamicChart } from "@/components/charts/DynamicChart";
import { cn } from "@/lib/utils";
import type { Widget, LayoutItem, ChartConfig } from "@/types";

interface DashboardGridProps {
    containerWidth: number;
    onWidgetDrop?: (x: number, y: number) => void;
}

// Widget size presets
const SIZE_PRESETS = {
    small: { w: 3, h: 3, label: "Nhỏ" },
    medium: { w: 6, h: 4, label: "Vừa" },
    large: { w: 9, h: 5, label: "Lớn" },
    full: { w: 12, h: 6, label: "Toàn bộ" },
};

const GRID_COLS = 12;
const CELL_HEIGHT = 60;
const GAP = 16;

export function DashboardGrid({ containerWidth }: DashboardGridProps) {
    const {
        currentDashboard,
        removeWidget,
        updateWidget,
        isEditing,
    } = useDashboardStore();

    const gridRef = useRef<HTMLDivElement>(null);
    const [showSizeMenu, setShowSizeMenu] = useState<string | null>(null);
    const [chartDataCache, setChartDataCache] = useState<Record<string, any[]>>({});
    const [gridRows, setGridRows] = useState(8);
    const [draggingWidgetId, setDraggingWidgetId] = useState<string | null>(null);

    const { setNodeRef, isOver } = useDroppable({
        id: "dashboard-grid",
    });

    // Calculate grid rows based on widget positions
    useEffect(() => {
        if (!currentDashboard) return;

        let maxRow = 8;
        currentDashboard.widgets.forEach(widget => {
            const y = widget.layout?.y || 0;
            const h = widget.layout?.h || 3;
            maxRow = Math.max(maxRow, y + h + 2);
        });
        setGridRows(maxRow);
    }, [currentDashboard?.widgets]);

    // Fetch chart data for chart widgets
    useEffect(() => {
        if (!currentDashboard) return;

        const fetchChartData = async (widgetId: string, config: ChartConfig) => {
            if (!config.dataSource?.table || !config.dataSource?.xAxis || !config.dataSource?.yAxis?.length) {
                return;
            }

            try {
                const response = await fetch("/api/database/chart-data", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        table: config.dataSource.table,
                        xAxis: config.dataSource.xAxis,
                        yAxis: config.dataSource.yAxis,
                        aggregation: config.dataSource.aggregation || "sum",
                        limit: 50,
                    }),
                });

                const result = await response.json();
                if (result.success && result.data) {
                    setChartDataCache(prev => ({
                        ...prev,
                        [widgetId]: result.data,
                    }));
                }
            } catch (error) {
                console.error("Error fetching chart data:", error);
            }
        };

        currentDashboard.widgets.forEach(widget => {
            if (widget.type === "chart" && !chartDataCache[widget.id]) {
                const config = widget.config as ChartConfig;
                fetchChartData(widget.id, config);
            }
        });
    }, [currentDashboard]);

    // Handle widget resize via presets
    const handleResize = useCallback((widgetId: string, size: keyof typeof SIZE_PRESETS) => {
        const preset = SIZE_PRESETS[size];
        const widget = currentDashboard?.widgets.find(w => w.id === widgetId);
        if (!widget) return;

        updateWidget(widgetId, {
            layout: {
                ...widget.layout,
                i: widgetId,
                w: preset.w,
                h: preset.h,
            }
        });
        setShowSizeMenu(null);
    }, [currentDashboard, updateWidget]);

    // Handle custom resize
    const handleCustomResize = useCallback((widgetId: string, deltaW: number, deltaH: number) => {
        const widget = currentDashboard?.widgets.find(w => w.id === widgetId);
        if (!widget) return;

        const currentLayout = widget.layout;
        const newW = Math.max(2, Math.min(12, (currentLayout?.w || 4) + deltaW));
        const newH = Math.max(2, (currentLayout?.h || 3) + deltaH);

        updateWidget(widgetId, {
            layout: {
                ...currentLayout,
                i: widgetId,
                w: newW,
                h: newH,
            }
        });
    }, [currentDashboard, updateWidget]);

    // Handle widget drag within grid
    const handleWidgetMouseDown = (widget: Widget, e: React.MouseEvent) => {
        if (!isEditing) return;
        e.preventDefault();

        setDraggingWidgetId(widget.id);
        const startX = e.clientX;
        const startY = e.clientY;
        const startLayoutX = widget.layout?.x || 0;
        const startLayoutY = widget.layout?.y || 0;
        const cellWidth = (containerWidth - (GRID_COLS - 1) * GAP) / GRID_COLS;

        const handleMouseMove = (moveEvent: MouseEvent) => {
            const deltaX = moveEvent.clientX - startX;
            const deltaY = moveEvent.clientY - startY;

            const colDelta = Math.round(deltaX / (cellWidth + GAP));
            const rowDelta = Math.round(deltaY / (CELL_HEIGHT + GAP));

            const w = widget.layout?.w || 4;
            const newX = Math.max(0, Math.min(GRID_COLS - w, startLayoutX + colDelta));
            const newY = Math.max(0, startLayoutY + rowDelta);

            updateWidget(widget.id, {
                layout: {
                    ...widget.layout,
                    i: widget.id,
                    x: newX,
                    y: newY,
                }
            });
        };

        const handleMouseUp = () => {
            setDraggingWidgetId(null);
            document.removeEventListener("mousemove", handleMouseMove);
            document.removeEventListener("mouseup", handleMouseUp);
        };

        document.addEventListener("mousemove", handleMouseMove);
        document.addEventListener("mouseup", handleMouseUp);
    };

    if (!currentDashboard) return null;

    const { widgets } = currentDashboard;

    // Render different widget types
    const renderWidgetContent = (widget: Widget) => {
        const height = ((widget.layout?.h || 3) * CELL_HEIGHT) - 60;

        switch (widget.type) {
            case "chart":
                const chartConfig = widget.config as ChartConfig;
                const chartData = chartDataCache[widget.id] || [];

                return (
                    <div className="w-full h-full flex flex-col">
                        {chartConfig.name && (
                            <div className="px-3 pt-2 pb-1">
                                <h4 className="text-sm font-medium text-[#0F172A] truncate">
                                    {chartConfig.name}
                                </h4>
                            </div>
                        )}
                        <div className="flex-1 min-h-0">
                            {chartData.length > 0 ? (
                                <DynamicChart
                                    config={chartConfig}
                                    data={chartData}
                                    height={Math.max(120, height)}
                                />
                            ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                    <div className="text-center text-[#94A3B8]">
                                        <BarChart3 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                                        <p className="text-xs">Đang tải...</p>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                );
            case "kpi":
                return (
                    <div className="flex flex-col items-center justify-center h-full">
                        <span className="text-sm text-[#64748B]">{(widget.config as any).title}</span>
                        <span className="text-3xl font-bold text-[#0F172A]">1,234</span>
                    </div>
                );
            case "text":
                return (
                    <div className="p-4 overflow-auto h-full">
                        <div
                            className={cn("prose max-w-none", {
                                "text-center": (widget.config as any).textAlign === "center",
                                "text-right": (widget.config as any).textAlign === "right",
                            })}
                            style={{ fontSize: (widget.config as any).fontSize || 16 }}
                        >
                            {(widget.config as any).content}
                        </div>
                    </div>
                );
            case "table":
                return (
                    <div className="p-4 h-full">
                        <p className="text-sm font-medium text-[#0F172A] mb-2">{(widget.config as any).title}</p>
                        <div className="border rounded text-xs text-[#64748B] p-2">
                            Bảng dữ liệu
                        </div>
                    </div>
                );
            default:
                return <div className="p-4 text-[#64748B]">Widget chưa hỗ trợ</div>;
        }
    };

    // Calculate absolute position for widget
    const getWidgetStyle = (layout: LayoutItem | undefined) => {
        const x = layout?.x || 0;
        const y = layout?.y || 0;
        const w = layout?.w || 4;
        const h = layout?.h || 3;

        const cellWidth = (containerWidth - (GRID_COLS - 1) * GAP) / GRID_COLS;

        return {
            position: "absolute" as const,
            left: x * (cellWidth + GAP),
            top: y * (CELL_HEIGHT + GAP),
            width: w * cellWidth + (w - 1) * GAP,
            height: h * CELL_HEIGHT + (h - 1) * GAP,
        };
    };

    const getSizeLabel = (layout: LayoutItem | undefined) => {
        const w = layout?.w || 4;
        const h = layout?.h || 3;
        return `${w}×${h}`;
    };

    const getPositionLabel = (layout: LayoutItem | undefined) => {
        const x = layout?.x || 0;
        const y = layout?.y || 0;
        return `(${x},${y})`;
    };

    const gridHeight = gridRows * CELL_HEIGHT + (gridRows - 1) * GAP;

    return (
        <div
            ref={(node) => {
                setNodeRef(node);
                (gridRef as any).current = node;
            }}
            className={cn(
                "rounded-lg transition-all relative",
                isEditing && "bg-[#F8FAFC]",
                isOver && "ring-4 ring-[#0052CC]/40 bg-[#0052CC]/5"
            )}
            style={{ minHeight: Math.max(500, gridHeight + 100) }}
        >
            {/* Grid background */}
            {isEditing && (
                <div
                    className="absolute inset-0 pointer-events-none"
                    style={{
                        display: "grid",
                        gridTemplateColumns: `repeat(${GRID_COLS}, 1fr)`,
                        gridAutoRows: `${CELL_HEIGHT}px`,
                        gap: `${GAP}px`,
                    }}
                >
                    {Array.from({ length: GRID_COLS * gridRows }).map((_, i) => (
                        <div
                            key={i}
                            className="border border-[#CBD5E1] rounded bg-white/60"
                        />
                    ))}
                </div>
            )}

            {/* Widgets container */}
            <div
                className="relative"
                style={{ height: gridHeight }}
            >
                {widgets.length === 0 ? (
                    <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center bg-white/90 p-8 rounded-xl border-2 border-dashed border-[#0052CC]/30 shadow-sm">
                            <GripVertical className="h-12 w-12 text-[#0052CC]/30 mx-auto mb-3" />
                            <p className="text-[#475569] font-medium mb-1">Kéo thả widget vào đây</p>
                            <p className="text-sm text-[#94A3B8]">Chọn widget từ thư viện bên trái</p>
                        </div>
                    </div>
                ) : (
                    widgets.map((widget) => (
                        <Card
                            key={widget.id}
                            className={cn(
                                "overflow-hidden bg-white shadow-md hover:shadow-lg transition-all group border-[#E2E8F0]",
                                isEditing && "border-2 border-[#0052CC]/40 hover:border-[#0052CC]",
                                draggingWidgetId === widget.id && "opacity-70 shadow-2xl z-50"
                            )}
                            style={getWidgetStyle(widget.layout)}
                        >
                            {/* Widget Header */}
                            {isEditing && (
                                <div
                                    className="absolute top-0 left-0 right-0 h-7 bg-[#0052CC] z-20 flex items-center justify-between px-2 cursor-move"
                                    onMouseDown={(e) => handleWidgetMouseDown(widget, e)}
                                >
                                    <div className="flex items-center gap-2">
                                        <Move className="h-3 w-3 text-white/70" />
                                        <span className="text-[10px] font-mono text-white/80">
                                            {getPositionLabel(widget.layout)} {getSizeLabel(widget.layout)}
                                        </span>
                                    </div>

                                    <div className="flex gap-1">
                                        <div className="relative">
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                className="h-5 w-5 text-white hover:bg-white/20"
                                                onMouseDown={(e) => e.stopPropagation()}
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    setShowSizeMenu(showSizeMenu === widget.id ? null : widget.id);
                                                }}
                                            >
                                                <Maximize2 className="h-3 w-3" />
                                            </Button>

                                            {showSizeMenu === widget.id && (
                                                <div
                                                    className="absolute top-6 right-0 bg-white shadow-xl rounded-lg border p-2 z-50 min-w-[140px]"
                                                    onMouseDown={(e) => e.stopPropagation()}
                                                    onClick={(e) => e.stopPropagation()}
                                                >
                                                    <p className="text-[10px] text-[#94A3B8] uppercase mb-2 px-1 font-medium">Kích thước</p>
                                                    {Object.entries(SIZE_PRESETS).map(([key, value]) => (
                                                        <button
                                                            key={key}
                                                            className="w-full text-left px-2 py-1.5 text-xs hover:bg-[#0052CC]/10 rounded flex justify-between items-center"
                                                            onClick={() => handleResize(widget.id, key as keyof typeof SIZE_PRESETS)}
                                                        >
                                                            <span>{value.label}</span>
                                                            <span className="text-[#94A3B8] font-mono text-[10px]">{value.w}×{value.h}</span>
                                                        </button>
                                                    ))}
                                                    <hr className="my-2" />
                                                    <div className="grid grid-cols-4 gap-1 px-1">
                                                        <button
                                                            className="px-1.5 py-1 text-[10px] bg-[#F1F5F9] rounded hover:bg-[#E2E8F0] font-medium"
                                                            onClick={() => handleCustomResize(widget.id, -1, 0)}
                                                        >
                                                            W−
                                                        </button>
                                                        <button
                                                            className="px-1.5 py-1 text-[10px] bg-[#F1F5F9] rounded hover:bg-[#E2E8F0] font-medium"
                                                            onClick={() => handleCustomResize(widget.id, 1, 0)}
                                                        >
                                                            W+
                                                        </button>
                                                        <button
                                                            className="px-1.5 py-1 text-[10px] bg-[#F1F5F9] rounded hover:bg-[#E2E8F0] font-medium"
                                                            onClick={() => handleCustomResize(widget.id, 0, -1)}
                                                        >
                                                            H−
                                                        </button>
                                                        <button
                                                            className="px-1.5 py-1 text-[10px] bg-[#F1F5F9] rounded hover:bg-[#E2E8F0] font-medium"
                                                            onClick={() => handleCustomResize(widget.id, 0, 1)}
                                                        >
                                                            H+
                                                        </button>
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-5 w-5 text-white hover:bg-red-500"
                                            onMouseDown={(e) => e.stopPropagation()}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                removeWidget(widget.id);
                                            }}
                                        >
                                            <X className="h-3 w-3" />
                                        </Button>
                                    </div>
                                </div>
                            )}

                            <CardContent className={cn("p-0 h-full", isEditing && "pt-7")}>
                                {renderWidgetContent(widget)}
                            </CardContent>

                            {/* Resize handle */}
                            {isEditing && (
                                <div
                                    className="absolute bottom-0 right-0 w-5 h-5 cursor-se-resize z-20"
                                    style={{
                                        background: "linear-gradient(135deg, transparent 50%, #0052CC 50%)",
                                        borderBottomRightRadius: "4px",
                                    }}
                                    onMouseDown={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();

                                        const startX = e.clientX;
                                        const startY = e.clientY;
                                        const startW = widget.layout?.w || 4;
                                        const startH = widget.layout?.h || 3;
                                        const cellWidth = (containerWidth - (GRID_COLS - 1) * GAP) / GRID_COLS;

                                        const handleMouseMove = (moveEvent: MouseEvent) => {
                                            const deltaX = moveEvent.clientX - startX;
                                            const deltaY = moveEvent.clientY - startY;
                                            const colDelta = Math.round(deltaX / (cellWidth + GAP));
                                            const rowDelta = Math.round(deltaY / (CELL_HEIGHT + GAP));

                                            const newW = Math.max(2, Math.min(12, startW + colDelta));
                                            const newH = Math.max(2, startH + rowDelta);

                                            updateWidget(widget.id, {
                                                layout: {
                                                    ...widget.layout,
                                                    i: widget.id,
                                                    w: newW,
                                                    h: newH,
                                                }
                                            });
                                        };

                                        const handleMouseUp = () => {
                                            document.removeEventListener("mousemove", handleMouseMove);
                                            document.removeEventListener("mouseup", handleMouseUp);
                                        };

                                        document.addEventListener("mousemove", handleMouseMove);
                                        document.addEventListener("mouseup", handleMouseUp);
                                    }}
                                />
                            )}
                        </Card>
                    ))
                )}
            </div>

            {showSizeMenu && (
                <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowSizeMenu(null)}
                />
            )}
        </div>
    );
}
